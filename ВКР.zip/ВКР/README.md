# Network Config Validator

Система для сбора, нормализации, проверки и аудита конфигураций сетевых устройств Cisco, Juniper, MikroTik, Arista EOS и Huawei VRP.

## Что умеет проект
- сбор конфигураций из файла и по SSH
- валидация одной конфигурации и пакетная проверка
- профильные и вендорные правила проверки
- поддержка пяти вендоров: Cisco, Juniper, MikroTik, Arista EOS, Huawei VRP
- сохранение raw и redacted конфигураций
- хранение снимков, нормализованных конфигураций и результатов проверок в PostgreSQL
- diff-анализ между снимками одного устройства
- базовая топологическая проверка на дубликаты IP и hostname
- выгрузка запусков и findings в CSV
- Prometheus-совместимый `/api/v1/metrics`
- Grafana, PostgreSQL и API через Docker Compose
- web dashboard `/api/v1/dashboard`
- ИИ-контур: LLM-анализ риска конфигурации через `/api/v1/ai/analyze` или флаг `include_ai` в `/api/v1/validate`

## Основные endpoint'ы
- `POST /api/v1/validate`
- `POST /api/v1/ai/analyze`
- `POST /api/v1/validate/bulk`
- `POST /api/v1/validate/topology`
- `POST /api/v1/collect`
- `POST /api/v1/collect-and-validate`
- `GET /api/v1/devices`
- `POST /api/v1/devices`
- `GET /api/v1/devices/{id}/diff`
- `GET /api/v1/runs`
- `GET /api/v1/metrics/summary`
- `GET /api/v1/metrics`
- `GET /api/v1/export/runs`
- `GET /api/v1/export/findings`
- `GET /api/v1/dashboard`

## ИИ-модель для диплома

ИИ-компонент проекта заменён на **ConfigGuard-Qwen2.5-3B-Instruct-Advisor**. Это архитектура локальной дообучаемой LLM-модели на базе `Qwen/Qwen2.5-3B-Instruct`, которая работает поверх нормализованной конфигурации и результатов детерминированной валидации.

Компонент возвращает:

- `risk_score` и `risk_level`;
- предполагаемый класс отказа `predicted_failure_kind`;
- ключевые факторы риска;
- объяснение результата;
- рекомендации по исправлению.

В проекте есть два режима:

- `CONFIGGUARD_AI_MODE=mock` — режим по умолчанию, работает без GPU, PyTorch, интернета и скачанных весов;
- `CONFIGGUARD_AI_MODE=local_llm` — локальный запуск Qwen2.5-3B-Instruct через `transformers`, с возможностью подключить LoRA-адаптер через `QWEN_ADAPTER_PATH`.

Стартовые данные для обучения добавлены в каталог `data/llm_training`:

- `configguard_qwen_train.jsonl`;
- `configguard_qwen_validation.jsonl`.

Скрипт дообучения LoRA/QLoRA находится в `scripts/train_qwen_lora.py`, дополнительные зависимости — в `requirements-llm.txt`. Подробности описаны в `docs/configguard_qwen_advisor.md`.

Пример вызова:

```bash
curl -X POST http://127.0.0.1:8000/api/v1/ai/analyze \
  -H "Content-Type: application/json" \
  -d @examples/request_cisco.json
```

Альтернативно можно вызвать обычную валидацию с полем `"include_ai": true`.

## Локальный запуск
```bash
python -m venv .venv
source .venv/bin/activate  # Linux/macOS
# .venv\Scripts\activate.bat  # Windows
pip install -r requirements.txt
cp .env.example .env
python -m pytest -q
uvicorn app.main:app --reload
```

## Docker
```bash
cp .env.example .env
docker compose build
docker compose up -d
```

- API docs: `http://127.0.0.1:8000/docs`
- Dashboard: `http://127.0.0.1:8000/api/v1/dashboard`
- Grafana: `http://127.0.0.1:3000`

## Mixed 1000-file dataset

This project version contains a built-in mixed dataset with exactly **1000 configuration files** under `configs/datasets`.

Supported vendors in the dataset:

| Vendor | Raw | Partial | Invalid | Total |
|---|---:|---:|---:|---:|
| Cisco | 140 | 45 | 15 | 200 |
| Juniper | 140 | 45 | 15 | 200 |
| MikroTik | 140 | 45 | 15 | 200 |
| Arista | 140 | 45 | 15 | 200 |
| Huawei | 140 | 45 | 15 | 200 |
| **Total** | **700** | **225** | **75** | **1000** |

The dataset combines existing curated project/sample configurations and controlled regression test cases. See:

- `configs/datasets/manifest_mixed_1000.json`
- `docs/dataset_mixed_1000.md`

Run dataset tests:

```bash
docker compose exec api pytest tests/test_dataset.py -q
docker compose exec api pytest tests/test_dataset_manifest_mixed_1000.py -q
```

By default, only a small representative subset of raw configs is passed through the full API to keep CI fast. To validate all raw configs through the API:

```bash
NCV_FULL_DATASET_API_TESTS=1 docker compose exec api pytest tests/test_dataset.py -q
```

Optional public external data importer:

```bash
python tools/import_public_datasets.py --clean
```

See `docs/public_external_dataset_import.md`.

