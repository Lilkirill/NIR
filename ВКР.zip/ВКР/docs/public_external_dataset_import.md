# Optional public external dataset importer

The project already contains the built-in `ncv_5vendor_mixed_1000` dataset with exactly 1000 files.

This optional importer can be used when an Internet connection is available and public-source licensing has been reviewed:

```bash
python tools/import_public_datasets.py --clean
```

The importer downloads public GitHub archives, extracts config-like files, classifies them into the supported vendors when possible, and stores them under:

```text
configs/datasets/public_external/
```

It also creates:

```text
configs/datasets/public_external/manifest_public_external.json
```

## Important academic note

Do not describe imported public files as private industrial production data unless you have provenance proving that claim. A safer wording is:

> Public external configuration snapshots and validation examples were used as an additional independent robustness check, while the built-in mixed dataset was used for controlled regression testing.

## Suggested workflow

1. Use the built-in 1000-file dataset for deterministic tests.
2. Optionally import public external data for additional robustness checks.
3. Keep imported public data in a separate `public_external` scope and cite the original repositories in the thesis.
4. Preserve license notices when redistributing imported files.
