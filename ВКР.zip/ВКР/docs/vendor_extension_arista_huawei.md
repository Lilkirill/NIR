# Vendor extension: Arista EOS and Huawei VRP

The project now supports five vendors: Cisco, Juniper, MikroTik, Arista EOS and Huawei VRP.

## Added components

- `app/parsers/arista.py` parses EOS-style running configuration.
- `app/parsers/huawei.py` parses Huawei VRP `display current-configuration` exports.
- `app/vendors/arista/adapter.py` and `app/vendors/huawei/adapter.py` implement the common vendor-adapter contract.
- `rules/vendors/arista.yaml` and `rules/vendors/huawei.yaml` define vendor-specific rules.
- `configs/samples/arista_ok.cfg` and `configs/samples/huawei_ok.cfg` provide smoke-test examples.
- `configs/datasets/arista` and `configs/datasets/huawei` add raw, partial and invalid dataset cases.

## Normalized fields

Both new parsers return the same normalized model used by the existing vendors:

- `vendor`
- `hostname`
- `interfaces`
- `routes`
- `services`
- `users`

This keeps the validation pipeline unchanged while moving syntax-specific logic into adapter/parser modules.

## Limitations

The new parsers are heuristic parsers intended for validation and regression datasets. They cover common interface, default-route, SSH and local-user patterns, but they do not implement full grammar-level parsing for every EOS or VRP feature.
