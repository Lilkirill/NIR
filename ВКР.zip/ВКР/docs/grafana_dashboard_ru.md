# Русифицированный dashboard Grafana

Файл dashboard обновлён: `grafana/dashboards/network_config_validator_dashboard.json`.

## Что изменено

- Все названия панелей переведены на русский язык.
- Названия колонок таблиц переведены на русский язык и не содержат нижних подчёркиваний.
- Панель «Все запуски по вендорам» растянута на всю ширину dashboard, чтобы таблица помещалась без горизонтальной прокрутки.
- Панель «Top finding codes» заменена на таблицу «Топ кодов нарушений».
- Панель «Operational runs by vendor» заменена на «API-запуски по вендорам», потому что в текущей базе эксплуатационные проверки представлены через `run_kind = 'api'`.
- Панель «Dataset runs by vendor» исправлена и теперь использует `run_kind = 'dataset'`.
- Панель «Total validation runs» теперь считает все записи из `validation_runs`, а не только API-запуски.

## Ожидаемые значения после полного тестового прогона

При текущем тестовом наборе ожидается примерно следующая картина:

- Всего запусков валидации: 799
- Датасетные запуски: 775
- API-запуски: 15
- Проваленные запуски: 77
- Вендоры: Cisco, Juniper, MikroTik, Arista, Huawei

## Как применить dashboard

После изменения файла dashboard перезапустите Grafana:

```bash
docker compose restart grafana
```

Если Grafana не подтянула изменения из файла, очистите только volume Grafana:

```bash
docker compose stop grafana
docker compose rm -f grafana
docker volume rm network_config_validator_enhanced_grafana_data
docker compose up -d grafana
```

Эти команды не удаляют PostgreSQL-данные с результатами запусков.
