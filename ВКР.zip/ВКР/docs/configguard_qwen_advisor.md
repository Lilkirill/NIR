# ConfigGuard-Qwen2.5-3B-Instruct-Advisor

ИИ-компонент проекта заменён на архитектуру **ConfigGuard-Qwen2.5-3B-Instruct-Advisor**.

## Назначение

Компонент работает после детерминированной валидации. На вход он получает:

- исходный текст конфигурации;
- нормализованную конфигурацию;
- найденные несоответствия (`findings`);
- статус формальной проверки;
- вендора, hostname, профиль и режим запуска.

На выходе формируется блок `ai_analysis`:

- `risk_score`;
- `risk_level`;
- `predicted_failure_kind`;
- `confidence`;
- `key_factors`;
- `explanation`;
- `recommendations`.

## Режимы работы

По умолчанию используется безопасный режим:

```bash
CONFIGGUARD_AI_MODE=mock
```

Он не требует GPU, PyTorch, внешнего API или скачанных весов модели. Поэтому основной проект и тесты продолжают работать сразу после распаковки.

Для запуска локальной Qwen-модели:

```bash
pip install -r requirements-llm.txt
export CONFIGGUARD_AI_MODE=local_llm
export QWEN_MODEL_PATH=Qwen/Qwen2.5-3B-Instruct
export QWEN_ADAPTER_PATH=models/configguard-qwen2.5-3b-lora
uvicorn app.main:app --reload
```

Если `QWEN_ADAPTER_PATH` не задан, будет использована базовая instruction-модель без предметного LoRA-адаптера.

## Обучающие данные

В проект добавлен стартовый набор данных:

- `data/llm_training/configguard_qwen_train.jsonl`;
- `data/llm_training/configguard_qwen_validation.jsonl`.

Формат — chat JSONL для supervised fine-tuning. Каждая строка содержит `system`, `user` и `assistant` сообщения.

Проверка датасета:

```bash
python scripts/validate_qwen_dataset.py
```

## Дообучение

Пример запуска LoRA/QLoRA:

```bash
pip install -r requirements-llm.txt
python scripts/train_qwen_lora.py \
  --model Qwen/Qwen2.5-3B-Instruct \
  --train data/llm_training/configguard_qwen_train.jsonl \
  --validation data/llm_training/configguard_qwen_validation.jsonl \
  --output models/configguard-qwen2.5-3b-lora \
  --qlora
```

В репозиторий не включены веса Qwen2.5-3B-Instruct и обученный LoRA-адаптер, так как они занимают существенно больше места, чем исходный проект. Включены код интеграции, скрипт обучения и стартовый предметный датасет.
