# Training data for ConfigGuard-Qwen2.5-3B-Instruct-Advisor

Файлы в этом каталоге подготовлены в формате chat JSONL для supervised fine-tuning Qwen2.5-3B-Instruct.

- `configguard_qwen_train.jsonl` — обучающие примеры.
- `configguard_qwen_validation.jsonl` — валидационные примеры.

Каждая строка содержит массив `messages`:

```json
{"messages": [{"role": "system", "content": "..."}, {"role": "user", "content": "..."}, {"role": "assistant", "content": "..."}]}
```

Модель должна научиться возвращать строгий JSON с полями:

- `risk_score`;
- `risk_level`;
- `predicted_failure_kind`;
- `confidence`;
- `key_factors`;
- `explanation`;
- `recommendations`.

Данные синтетические, но предметно согласованы с конвейером проекта: на вход подаются `vendor`, `hostname`, `validation_status`, `normalized_config`, `findings` и фрагмент исходной конфигурации. Для диплома это можно описывать как стартовый предметный датасет, который расширяется результатами регрессионных запусков и экспертной разметкой администратора.
